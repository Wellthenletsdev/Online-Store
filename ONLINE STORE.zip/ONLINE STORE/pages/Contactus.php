<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./pages/about.css">
    <script src="https://kit.fontawesome.com/dbed6b6114.js" crossorigin="anonymous"></script>
    </head>
    <title>Document</title>
</head>

    <body>
        <button>
        <a href="./pages/catalog.php">BACK HOME</a>
</button>

        <div class = "products">
            <div class = "container">
                <h1 class = "lg-title">SOUTH SIDE AUTOSTYLES</h1>
                <p class = "text-light"></p>

<footer>
  <h2 id="Contact" class="aquamarine-h2">Contact US ON THE FOllowing pages</h2>


  <a href="https://www.facebook.com" target="_blank"> <img class="icons" src="images/facebook-icon (1).jpg" alt="https://
    www.facebook.com/motlhalefim">
  </a>
  <a href="https://www.gmail.com" target="_blank"><i class="fa-address-book"></i> </a>
  <a href="https://www.linkedin.com" target="_blank"> <img class="icons" src="images/linkdin.jpg" ></a>
  






















    
                    <style>
@import url('https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700;900&display=swap');

:root{
    --white-light: rgba(255, 255, 255, 0.5);
    --alice-blue: #f8f9fa;
    --carribean-green: #e90f1e;
    --gray: #ededed;
}
*{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}
body{
    font-family: 'Quicksand', sans-serif;
}

/* Utility stylings */
img{
    width: 100%;
    display: block;
}
.container{
    width: 88vw;
    margin: 0 auto;
}
.lg-title,
.md-title,
.sm-title{
    font-family: 'Roboto', sans-serif;
    padding: 0.6rem 0;
    text-transform: capitalize;
}
.lg-title{
    font-size: 2.5rem;
    font-weight: 500;
    text-align: center;
    padding: 1.3rem 0;
    opacity: 0.9;
}
.md-title{
    font-size: 2rem;
    font-family: 'Roboto', sans-serif;
}
.sm-title{
    font-weight: 300;
    font-size: 1rem;
    text-transform: uppercase;
}
.text-light{
    font-size: 1rem;
    font-weight: 600;
    line-height: 1.5;
    opacity: 0.5;
    margin: 0.4rem 0;
}


                    </style>
     

       
        
    

    
</body>
</html>